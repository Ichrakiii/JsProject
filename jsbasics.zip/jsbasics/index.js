console.log('hello world');
let name='ichrak';
